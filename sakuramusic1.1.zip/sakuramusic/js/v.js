var app = new Vue({
    el:"#wrapper",
    data:{
        query:"",
        musicList:[],
        likeList:[],
        playList:[],
        searchList:[],
        likeIndex:0,
        playIndex:0,
        show:{
            songs:"",
            likes:"",
            plays:""
        },
        musicUrl:""
    },
    methods:{
        searchMusic:function(){
            let q = this.query
            var that = this
            if(!that.searchList[q])
            {
                axios.get("https://autumnfish.cn/search?keywords="+q).then(function(response){
                    that.musicList = response.data.result.songs
                    that.searchList[q] = response.data.result.songs
                },function(err){})
            }
            else{
                that.musicList = that.searchList[q]
            }
        },
        playMusic:function(item){
            var that = this
            axios.get("https://autumnfish.cn/song/url?id="+item.id).then(function(response){
                if(response.data.data[0].url == null){
                    let nonePlay = document.getElementById(item.id*(item.ftype+1)-1000000)
                    nonePlay.id = 'NaN'
                    item.ftype = "x"
                    var tip = document.getElementById("tipNoShow")
                    tip.id = "tipShow"
                    console.log(tip.id);
                    setTimeout(() => {
                        tip.id = "tipNoShow"
                        console.log(tip.id);
                    }, 700);
                }
                else
                that.musicUrl = response.data.data[0].url
            },function (err) {})
        },
        changeShow:function(showThing){
            this.show.songs = ""
            this.show.likes = ""
            this.show.plays = ""
            this.show[showThing] = showThing
        },
        clone:function(item,list){
            function deepClone(obj) {
                (function(){
                    for(let key in arguments){
                        if(obj instanceof window[arguments[key]])
                        return new window[arguments[key]](obj)
                    }
                })('Date','RegExp','Error')
                if(typeof obj === 'function')
                return eval('(' + obj.toString() + ')')
                if (obj === null) return null
                if (typeof obj !== "object") return obj
                let newObj = new obj.constructor
                for (let key in obj) {
                    if (obj.hasOwnProperty(key)) {
                        newObj[key] = deepClone(obj[key])
                    }
                }
                return newObj
            }

            let lI = this.likeIndex
            let pI = this.playIndex
            switch(list){
                case 'likeList':
                    let noneLike = document.getElementById(item.id*(item.status+1))
                    noneLike.id = 'NaN'
                    item.status = "x"
                    this.likeList[lI] = deepClone(item)
                    this.likeIndex++
                    break
                case 'playList':
                    let nonePlay = document.getElementById(item.id*(item.rtype+1)-100000)
                    nonePlay.id = 'NaN'
                    item.rtype = "x"
                    this.playList[pI] = deepClone(item)
                    this.playIndex++
                    break
            }
            
            
        }
        }
})