var app = new Vue({
    el:"#wrapper",
    data:{
        query:"",
        musicList:[],
        likeList:[],
        playList:[],
        likeIndex:0,
        playIndex:0,
        show:{
            songs:"",
            likes:"",
            plays:""
        },
        musicUrl:""
    },
    methods:{
        searchMusic:function(){
            var that = this
                axios.get("https://autumnfish.cn/search?keywords="+this.query).then(function(response){
                    that.musicList = response.data.result.songs
                },function(err){})
        },
        playMusic:function(musicId){
            var that = this
            axios.get("https://autumnfish.cn/song/url?id="+musicId).then(function(response){
                that.musicUrl = response.data.data[0].url
            },function (err) {})
        },
        changeShow:function(showThing){
            this.show.songs = ""
            this.show.likes = ""
            this.show.plays = ""
            this.show[showThing] = showThing
        },
        clone:function(item,list){
            function deepClone(obj) {
                (function(){
                    for(let key in arguments){
                        if(obj instanceof window[arguments[key]])
                        return new window[arguments[key]](obj)
                    }
                })('Date','RegExp','Error')
                if(typeof obj === 'function')
                return eval('(' + obj.toString() + ')')
                if (obj === null) return null
                if (typeof obj !== "object") return obj
                let newObj = new obj.constructor
                for (let key in obj) {
                    if (obj.hasOwnProperty(key)) {
                        newObj[key] = deepClone(obj[key])
                    }
                }
                return newObj
            }
            let lI = this.likeIndex
            let pI = this.playIndex
            switch(list){
                case 'likeList':
                    let noneLike = document.getElementById(item.id)
                    noneLike.id = "x"
                    this.likeList[lI] = deepClone(item)
                    this.likeIndex++
                    break
                case 'playList':
                    let nonePlay = document.getElementById(item.id-100000)
                    nonePlay.id = "x"
                    this.playList[pI] = deepClone(item)
                    this.playIndex++
                    break
            }
            
            
        }
        }
})