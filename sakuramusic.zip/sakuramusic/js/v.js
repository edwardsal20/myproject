var app = new Vue({
    el:"#wrapper",
    data:{
        query:"",
        musicList:[],
        likeList:[],
        playList:[],
        show:{
            songs:"",
            likes:"",
            plays:""
        },
        musicUrl:""
    },
    methods:{
        searchMusic:function(){
            var that = this
                axios.get("https://autumnfish.cn/search?keywords="+this.query).then(function(response){
                    that.musicList = response.data.result.songs
                },function(err){})
        },
        playMusic:function(musicId){
            var that = this
            axios.get("https://autumnfish.cn/song/url?id="+musicId).then(function(response){
                that.musicUrl = response.data.data[0].url
            },function (err) {})
        },
        changeShow:function(showThing){
            this.show.songs = ""
            this.show.likes = ""
            this.show.plays = ""
            this.show[showThing] = showThing
        }
        }
})